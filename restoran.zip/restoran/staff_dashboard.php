<?php
session_start();
if (!isset($_SESSION['nm_user']) || $_SESSION['role'] != 'staff') {
    
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Staff Dashboard</title>
</head>
<body>
    <h1>Selamat datang di Staff Dashboard</h1>
    <p>Halo, <?php echo $_SESSION['username']; ?></p>
    <!-- Tambahkan kode untuk menampilkan data dan opsi manajemen untuk staf -->
</body>
</html>
