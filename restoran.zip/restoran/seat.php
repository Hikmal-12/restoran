<?php
include('db.php');
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Atur zona waktu ke WIB
date_default_timezone_set('Asia/Jakarta');
$tanggal_jam_sekarang = date("d-m-Y H:i:s");

// Query untuk menampilkan data seat
$sql = "SELECT * FROM seat";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Daftar Seat</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Gaya umum */
        body { font-family: 'Segoe UI', Tahoma, sans-serif; margin: 0; background-color: #f0f0f5; color: #333; }
        h2 { text-align: center; color: #333; margin-top: 20px; font-size: 28px; }
        
        /* Navigasi */
        .nav-bar { display: flex; justify-content: flex-end; gap: 10px; padding: 10px 20px; background-color: #ff7e5f; }
        .nav-bar button { padding: 8px 16px; color: #fff; background-color: #333; border: none; border-radius: 4px; cursor: pointer; transition: 0.3s; }
        .nav-bar button:hover { background-color: #555; }
        
        /* Konten utama */
        .welcome { text-align: left; margin: 20px; font-weight: bold; color: #555; }
        .seat-container { display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; margin-top: 20px; padding: 0 10px; }
        
        /* Box seat */
        .seat-box { width: calc(100% - 40px); max-width: 220px; padding: 15px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); text-align: center; transition: transform 0.3s ease; }
        .seat-box:hover { transform: scale(1.05); }
        .seat-box p { margin: 5px 0; font-size: 16px; }
        .seat-box button { padding: 8px 12px; margin-top: 10px; background-color: #333; color: #fff; border: none; border-radius: 4px; cursor: pointer; transition: background-color 0.3s; }
        .seat-box button:hover { background-color: #555; }

        /* Footer */
        .footer { display: flex; justify-content: center; gap: 15px; margin-top: 30px; padding-bottom: 20px; }
        .footer button { padding: 10px 20px; color: #fff; background-color: #ff7e5f; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; transition: background-color 0.3s; }
        .footer button:hover { background-color: #eb6a4f; }

        /* Responsif */
        @media (min-width: 600px) {
            .seat-box { width: calc(50% - 40px); }
        }

        @media (min-width: 768px) {
            .seat-box { width: calc(33.33% - 40px); }
        }

        @media (min-width: 1024px) {
            .seat-box { width: calc(25% - 40px); }
        }
    </style>
</head>
<body>
    <div class="nav-bar">
        <button onclick="location.href='dashboard.php'">Dashboard</button>
        <button onclick="location.href='seat.php'">Seat</button>
        <button onclick="location.href='menu_tersedia.php'">Menu</button>
        <button onclick="location.href='reservasi.php'">Reservasi</button>
        <button onclick="location.href='pesanan.php'">Pesanan</button>
        <button onclick="location.href='pembayaran.php'">Bayar</button>
        <button onclick="location.href='logout.php'">Logout</button>
    </div>

    <h2>Daftar Seat</h2>
    <p class="welcome">Selamat datang!, <?php echo $_SESSION['username']; ?> | <?php echo $tanggal_jam_sekarang; ?></p>

    <div class="seat-container">
        <?php
        while ($row = $result->fetch_assoc()) {
            echo "<div class='seat-box'>";
            echo "<p><strong>Nama Seat:</strong> {$row['nm_seat']}</p>";
            echo "<p><strong>Kapasitas:</strong> {$row['cap_seat']}</p>";
            echo "<p><strong>Deskripsi:</strong> {$row['desc_seat']}</p>";
            echo "<p><strong>Status:</strong> {$row['status_seat']}</p>";
            echo "<button onclick=\"location.href='reservasi.php?id_seat={$row['id_seat']}'\">Reservasi</button>";
            echo "</div>";
        }
        ?>
    </div>

    <div class="footer">
        <button onclick="location.href='tambah_seat.php'">Tambah Seat</button>
        <button onclick="location.href='reservasi_terjadwal.php'">Booked Seat</button>
    </div>
</body>
</html>
