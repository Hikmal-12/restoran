<?php
include('db.php');
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Ambil id_rsv dari URL
$id_rsv = isset($_GET['id']) ? $_GET['id'] : '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mendapatkan data dari form edit
    $datetime_rsv = $_POST['datetime_rsv'];
    $nm_cust = $_POST['nm_cust'];
    $phn_cust = $_POST['phn_cust'];

    // Update data reservasi di database
    $sql_update = "UPDATE reservation
                   JOIN customer ON reservation.id_cust = customer.id_cust
                   SET reservation.datetime_rsv = '$datetime_rsv', customer.nm_cust = '$nm_cust', customer.phn_cust = '$phn_cust'
                   WHERE reservation.id_rsv = '$id_rsv'";

    if ($conn->query($sql_update) === TRUE) {
        header("Location: reservasi.php");
        exit();
    } else {
        $error_message = "Gagal memperbarui data reservasi.";
    }
}

// Ambil data reservasi yang akan diedit
$sql = "SELECT reservation.id_rsv, reservation.datetime_rsv, customer.nm_cust AS customer_name, customer.phn_cust AS customer_phone
        FROM reservation
        JOIN customer ON reservation.id_cust = customer.id_cust
        WHERE reservation.id_rsv = '$id_rsv'";

$result = $conn->query($sql);
$reservation = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Edit Reservasi</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f2f2f2; }
        .form-container { width: 400px; margin: 50px auto; padding: 20px; background: #fff; border: 1px solid #ddd; }
        input[type="text"], input[type="datetime-local"] { width: 100%; padding: 10px; margin: 10px 0; }
        button { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
        .error { color: red; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit Reservasi</h2>
        <form action="edit_reservation.php?id=<?php echo $id_rsv; ?>" method="post">
            <label for="datetime_rsv">Tanggal Reservasi:</label>
            <input type="datetime-local" name="datetime_rsv" value="<?php echo date('Y-m-d\TH:i', strtotime($reservation['datetime_rsv'])); ?>" required>

            <label for="nm_cust">Nama Pelanggan:</label>
            <input type="text" name="nm_cust" value="<?php echo $reservation['customer_name']; ?>" required>

            <label for="phn_cust">No. Telepon:</label>
            <input type="text" name="phn_cust" value="<?php echo $reservation['customer_phone']; ?>" required>

            <button type="submit">Simpan Perubahan</button>
        </form>
        <?php if (isset($error_message)) { echo "<p class='error'>$error_message</p>"; } ?>
    </div>
</body>
</html>
