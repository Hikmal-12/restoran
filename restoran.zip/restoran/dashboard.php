<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include('db.php');

// Mengambil nama pengguna yang login dari sesi
$username = $_SESSION['username'];

// Mendapatkan tanggal dan waktu saat ini
date_default_timezone_set("Asia/Jakarta");
$current_date = date("d-m-Y");
$current_time = date("H:i:s");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restoran</title>
    <style>
        /* Import font */
        @font-face {
            font-family: "Forte";
            src: url("path/to/forte.ttf"); /* Ganti path sesuai dengan lokasi file font */
        }

        /* Reset CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        /* Container styling */
        .container {
            width: 90%;
            max-width: 600px;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
            text-align: center;
        }

        /* Header styling */
        h1 {
            font-family: "Forte", sans-serif;
            color: #007bff;
            font-size: 2.2em;
            margin-bottom: 10px;
        }

        p {
            font-size: 1em;
            color: #666;
            margin-bottom: 20px;
        }

        /* Button container */
        .buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            justify-content: center;
            margin-bottom: 20px;
        }

        /* Button styling */
        .button {
            flex: 1 1 45%;
            padding: 12px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            color: #fff;
            transition: background-color 0.3s ease, transform 0.2s ease;
            text-align: center;
        }

        .button-blue {
            background-color: #007bff;
        }
        .button-blue:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .button-yellow {
            background-color: #ffc107;
            color: #333;
        }
        .button-yellow:hover {
            background-color: #d39e00;
            transform: scale(1.05);
        }

        /* Logout button styling */
        .logout {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            color: #fff;
            background-color: #d9534f;
            border-radius: 8px;
            text-decoration: none;
            font-size: 15px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .logout:hover {
            background-color: #c9302c;
            transform: scale(1.05);
        }

        /* Responsive adjustments */
        @media (min-width: 768px) {
            .container {
                max-width: 700px;
                padding: 40px;
            }
            h1 {
                font-size: 2.5em;
            }
            p {
                font-size: 1.1em;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Resto Mz</h1>
    <p>Selamat datang, <strong><?php echo htmlspecialchars($username); ?></strong>!</p>
    <p>Tanggal: <?php echo $current_date; ?> | Jam: <?php echo $current_time; ?></p>

    <div class="buttons">
        <!-- Tombol fitur utama -->
        <button class="button button-blue" onclick="window.location.href='seat.php'">Lihat Seat</button>
        <button class="button button-blue" onclick="window.location.href='menu_tersedia.php'">Lihat Menu</button>
        <button class="button button-blue" onclick="window.location.href='reservasi.php'">Reservasi</button>
        <button class="button button-blue" onclick="window.location.href='pesanan.php'">Mulai Pesan Menu</button>
        <button class="button button-blue" onclick="window.location.href='pembayaran.php'">Bayar Pesanan</button>
        <button class="button button-blue" onclick="window.location.href='reservasi_terjadwal.php'">Lihat Booking Terjadwal</button>

        <!-- Tombol fitur tambahan -->
        <button class="button button-yellow" onclick="window.location.href='staff_dashboard.php'">Cek Staff</button>
        <button class="button button-yellow" onclick="window.location.href='lihat_laporan_penjualan.php'">Lihat Laporan Penjualan</button>
    </div>

    <a href="logout.php" class="logout">Logout</a>
</div>

</body>
</html>
