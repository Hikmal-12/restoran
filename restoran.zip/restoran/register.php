<?php
// Koneksi ke database
include('db.php'); // Pastikan file db.php sudah benar

// Memulai sesi
session_start();

// Proses registrasi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nm_user = $_POST['nm_user'];
    $ttl_user = $_POST['ttl_user'];
    $email_user = $_POST['email_user'];
    $hp_user = $_POST['hp_user'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Periksa apakah username sudah digunakan
    $checkUsername = "SELECT * FROM user WHERE username = '$username'";
    $result = $conn->query($checkUsername);

    if ($result->num_rows > 0) {
        $error_message = "Username sudah digunakan, pilih username lain.";
    } else {
        // Masukkan data ke tabel `user`
        $sqlUser = "INSERT INTO user (nm_user, ttl_user, email_user, hp_user, username, password)
                    VALUES ('$nm_user', '$ttl_user', '$email_user', '$hp_user', '$username', '$password')";

        if ($conn->query($sqlUser) === TRUE) {
            // Redirect ke halaman login setelah sukses
            header("Location: login.php");
            exit();
        } else {
            $error_message = "Gagal mendaftarkan akun. Silakan coba lagi.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Registrasi - Restoran</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Gaya umum */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .register-form {
            width: 90%;
            max-width: 400px;
            padding: 20px;
            border-radius: 8px;
            background: linear-gradient(135deg, #ff7e5f, #feb47b);
            color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
            transition: transform 0.3s ease;
        }
        .register-form:hover {
            transform: scale(1.03);
        }
        h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #fff;
            font-family: 'Trebuchet MS', sans-serif;
        }
        input[type="text"],
        input[type="email"],
        input[type="date"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #fff;
            border-radius: 5px;
            font-size: 16px;
            color: #333;
        }
        button {
            padding: 12px 20px;
            font-size: 16px;
            font-weight: bold;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
            width: 100%;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #555;
        }
        .error {
            color: #ffcccb;
            margin-top: 10px;
            font-size: 14px;
        }
        @media (min-width: 768px) {
            .register-form { padding: 30px; }
            h2 { font-size: 28px; }
            button { font-size: 18px; }
        }
    </style>
</head>
<body>
    <div class="register-form">
        <h2>Registrasi Akun</h2>
        <form action="register.php" method="post">
            <input type="text" name="nm_user" placeholder="Nama Lengkap" required>
            <input type="date" name="ttl_user" placeholder="Tanggal Lahir" required>
            <input type="email" name="email_user" placeholder="Email" required>
            <input type="text" name="hp_user" placeholder="No. Handphone" required>
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Daftar</button>
        </form>
        
        <?php
        if (isset($error_message)) {
            echo '<p class="error">' . $error_message . '</p>';
        }
        ?>
    </div>
</body>
</html>
