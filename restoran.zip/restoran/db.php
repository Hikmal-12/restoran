<?php
$servername = "localhost"; // Gunakan hanya "localhost"
$username = "root";
$password = ""; // Kosongkan jika password belum diatur
$dbname = "restoran";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
