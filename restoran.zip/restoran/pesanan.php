<?php
// Koneksi database dan sesi
include('db.php');
session_start();

// Set timezone ke Cilegon
date_default_timezone_set('Asia/Jakarta');

// Pastikan pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Ambil data pengguna dan waktu saat ini
$nm_user = $_SESSION['username'];
$now = date("d-m-Y H:i");

// Proses pesanan saat form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['proses-pesanan'])) {
    $id_rsv = $_POST['rsv_no'] ?? '';
    $nm_cust = $_POST['cust_name'] ?? '';
    $seat = $_POST['seat'] ?? '';
    $id_menu = $_POST['menu_id'] ?? [];
    $qty_order = $_POST['quantity'] ?? [];
    $desc_order = $_POST['keterangan'] ?? [];

    if ($id_rsv && $nm_cust && $seat && !empty($id_menu)) {
        $id_orders = uniqid(); // Generate unique ID untuk pesanan
        $total_price = 0;

        // Mulai transaksi
        $conn->begin_transaction();

        try {
            // Insert ke tabel `orders`
            $orderQuery = "INSERT INTO orders (id_orders, id_rsv, no_order, item_orders, total_orders) VALUES (?, ?, ?, ?, ?)";
            $stmtOrder = $conn->prepare($orderQuery);
            $item_order = count($id_menu);
            $stmtOrder->bind_param("sssii", $id_orders, $id_rsv, $id_orders, $item_order, $total_price);
            $stmtOrder->execute();

            // Proses setiap menu yang dipesan
            foreach ($id_menu as $index => $menu_id) {
                $qty = $qty_order[$index] ?? 1;
                $desc = $desc_order[$index] ?? '';

                // Ambil harga menu dari database
                $priceQuery = "SELECT price_menu FROM menu WHERE id_menu = ?";
                $stmtPrice = $conn->prepare($priceQuery);
                $stmtPrice->bind_param("s", $menu_id);
                $stmtPrice->execute();
                $stmtPrice->bind_result($price_menu);
                $stmtPrice->fetch();
                $stmtPrice->close();

                $total_price += $price_menu * $qty;

                // Insert ke tabel `ordersmenu`
                $orderMenuQuery = "INSERT INTO id_ordersmenu (id_orders, id_menu, qty_ordmenu, desc_ordmenu) VALUES (?, ?, ?, ?)";
                $stmtOrderMenu = $conn->prepare($orderMenuQuery);
                $stmtOrderMenu->bind_param("ssis", $id_orders, $menu_id, $qty, $desc);
                $stmtOrderMenu->execute();
            }

            // Update total harga di tabel `orders`
            $updateOrderQuery = "UPDATE orders SET total_orders = ? WHERE id_orders = ?";
            $stmtUpdateOrder = $conn->prepare($updateOrderQuery);
            $stmtUpdateOrder->bind_param("is", $total_price, $id_orders);
            $stmtUpdateOrder->execute();

            // Commit transaksi
            $conn->commit();

            // Redirect ke halaman pembayaran
            header("Location: pembayaran.php?order_id=$id_orders");
            exit();
        } catch (Exception $e) {
            // Rollback jika terjadi error
            $conn->rollback();
            echo "Error processing order: " . $e->getMessage();
        }
    } else {
        echo "<script>alert('Silakan lengkapi semua kolom yang diperlukan!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f8fc;
            color: #333;
        }
        .sidebar {
            float: left;
            width: 20%;
            background-color: #4b6584;
            padding: 15px;
            height: 100vh;
        }
        .sidebar h3 {
            font-family: 'Forte', sans-serif;
            font-size: 24px;
            color: #ffd700;
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar button {
            display: block;
            width: 100%;
            margin-bottom: 10px;
            padding: 10px;
            background-color: #fff;
            color: #4b6584;
            border: none;
            cursor: pointer;
            font-weight: bold;
        }
        .sidebar button:hover {
            background-color: #ffd700;
            color: #333;
        }
        .container {
            margin-left: 22%;
            padding: 20px;
        }
        .container h2 {
            font-size: 28px;
            color: #4b6584;
            margin-bottom: 20px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .table th, .table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
            font-size: 14px;
        }
        .table th {
            background-color: #4b6584;
            color: #fff;
        }
        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .btn {
            padding: 10px 15px;
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 4px;
        }
        .btn:hover {
            background-color: #218838;
        }
        #search-bar {
            margin-bottom: 15px;
            padding: 10px;
            width: 100%;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
    <script>
        function addToOrder(menuId, menuName, qtyInputId) {
            const quantity = document.getElementById(qtyInputId).value;
            if (quantity) {
                const orderList = document.getElementById('order-list');
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${menuId}</td>
                    <td>${menuName}</td>
                    <td>${quantity}</td>
                    <td><input type="text" name="keterangan[]" placeholder="Isi keterangan"></td>
                    <input type="hidden" name="menu_id[]" value="${menuId}">
                    <input type="hidden" name="quantity[]" value="${quantity}">
                `;
                orderList.appendChild(row);
                updateTotalItems();
            }
        }

        function updateTotalItems() {
            const items = document.querySelectorAll('#order-list tr').length;
            document.getElementById('total-item').textContent = items;
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <h3>Resto Mz</h3>
        <button onclick="location.href='dashboard.php'">Dashboard</button>
        <button onclick="location.href='menu.php'">Menu</button>
        <button onclick="location.href='reservasi.php'">Reservasi</button>
        <button onclick="location.href='logout.php'">Logout</button>
    </div>

    <div class="container">
        <h2>Pesanan</h2>
        <p>Selamat datang, <?php echo $nm_user; ?> | <?php echo $now; ?></p>
        
        <!-- Form -->
        <form method="POST">
            <h3>Order List</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Menu</th>
                        <th>Jumlah</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody id="order-list"></tbody>
            </table>
            <p>Total Item: <span id="total-item">0</span></p>
            
            <button type="submit" name="proses-pesanan" class="btn">Proses Pesanan</button>
        </form>
    </div>
</body>
</html>
