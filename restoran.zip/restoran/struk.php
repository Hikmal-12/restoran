<?php
include('db.php');
session_start();

// Check if the order ID is set (assuming it was passed as a query parameter)
if (!isset($_GET['order_id'])) {
    echo "Order ID is missing!";
    exit();
}

$order_id = $_GET['order_id'];

// Query for order details
$orderQuery = "SELECT o.id_orders, o.id_rsv, o.no_orders, o.item_orders, o.total_orders, r.customer_name, r.seat 
               FROM orders o
               JOIN rsv r ON o.id_rsv = r.id_rsv
               WHERE o.id_orders = ?";
$stmtOrder = $conn->prepare($orderQuery);
$stmtOrder->bind_param("s", $order_id);
$stmtOrder->execute();
$orderResult = $stmtOrder->get_result();

if ($orderResult->num_rows == 0) {
    echo "Order not found!";
    exit();
}

$orderData = $orderResult->fetch_assoc();

// Query for order menu items
$menuQuery = "SELECT m.id_menu, m.name_menu, om.qty_ordmenu, om.desc_ordmenu 
              FROM id_ordersmenu om
              JOIN menu m ON om.id_menu = m.id_menu
              WHERE om.id_orders = ?";
$stmtMenu = $conn->prepare($menuQuery);
$stmtMenu->bind_param("s", $order_id);
$stmtMenu->execute();
$menuResult = $stmtMenu->get_result();

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Struk Pesanan</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f7f8fc; color: #333; padding: 20px; }
        .receipt { max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; background-color: #fff; }
        h2 { text-align: center; color: #4b6584; margin-bottom: 20px; }
        .info { margin-bottom: 20px; }
        .info p { margin: 5px 0; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        table, th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #4b6584; color: #fff; }
        .total { font-weight: bold; text-align: right; }
        .btn { padding: 10px 15px; background-color: #28a745; color: white; border: none; cursor: pointer; text-align: center; display: block; margin: 20px auto; width: 150px; border-radius: 4px; text-decoration: none; text-align: center; }
        .btn:hover { background-color: #218838; }
    </style>
</head>
<body>
    <div class="receipt">
        <h2>Struk Pesanan</h2>
        <div class="info">
            <p><strong>No Order:</strong> <?php echo $orderData['no_orders']; ?></p>
            <p><strong>RSV No:</strong> <?php echo $orderData['id_rsv']; ?></p>
            <p><strong>Nama Pelanggan:</strong> <?php echo $orderData['customer_name']; ?></p>
            <p><strong>Seat:</strong> <?php echo $orderData['seat']; ?></p>
            <p><strong>Total Item:</strong> <?php echo $orderData['item_orders']; ?></p>
        </div>
        <table>
            <thead>
                <tr>
                    <th>ID Menu</th>
                    <th>Nama Menu</th>
                    <th>Jumlah</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $menuResult->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id_menu']; ?></td>
                        <td><?php echo $row['name_menu']; ?></td>
                        <td><?php echo $row['qty_ordmenu']; ?></td>
                        <td><?php echo $row['desc_ordmenu']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <p class="total"><strong>Total Orders:</strong> <?php echo number_format($orderData['total_orders'], 2); ?></p>
        <a href="pesanan.php" class="btn">Kembali</a>
    </div>
</body>
</html>
