<?php
include('db.php'); // Menghubungkan ke database
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk memeriksa username dan password
    $sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Login berhasil, set session user
        $row = $result->fetch_assoc();
        $_SESSION['id_user'] = $row['id_user'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['nm_user'] = $row['nm_user'];

        // Redirect ke dashboard
        header("Location: dashboard.php");
        exit();
    } else {
        // Login gagal, tampilkan pesan error
        $error_message = "Username atau password salah. Silakan coba lagi.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Login - Restoran Mz</title>
    <style>
        @font-face {
            font-family: 'Forte';
            src: url('Forte.ttf') format('truetype');
        }

        /* Desain dasar */
        body {
            font-family: Arial, sans-serif;
            background-color: #ffffff; /* Background putih */
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            flex-direction: column;
        }

        .login-form {
            width: 90%;
            max-width: 400px;
            padding: 30px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        h2 {
            font-family: 'Forte', Arial, sans-serif;
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
        }

        p.description {
            font-size: 16px;
            color: #555;
            margin-bottom: 20px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
        }

        button.clear {
            background-color: #f44336;
            color: white;
        }

        button.register {
            background-color: #008CBA;
            color: white;
        }

        button:hover {
            opacity: 0.9;
        }

        .toggle-password {
            cursor: pointer;
            font-size: 14px;
            color: #007BFF;
            margin-top: -10px;
            display: inline-block;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }

        /* Footer sederhana */
        footer {
            text-align: center;
            margin-top: auto;
            font-size: 14px;
            color: #555;
            width: 100%;
            padding: 10px;
            background-color: #f9f9f9;
            border-top: 1px solid #ddd;
            position: absolute;
            bottom: 0;
        }
    </style>
    <script>
        // Fungsi untuk mengubah tipe input password agar bisa dilihat atau disembunyikan
        function togglePassword() {
            var passwordField = document.getElementById("password");
            var toggleText = document.getElementById("toggle-password");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleText.innerText = "Sembunyikan Password";
            } else {
                passwordField.type = "password";
                toggleText.innerText = "Lihat Password";
            }
        }

        // Fungsi untuk membersihkan form
        function clearForm() {
            document.getElementById("username").value = "";
            document.getElementById("password").value = "";
        }
    </script>
</head>
<body>
    <div class="login-form">
        <h2>Restoran Mz</h2>
        <p class="description">Silahkan login untuk menikmati layanan terbaik kami</p>
        
        <form action="login.php" method="post">
            <input type="text" id="username" name="username" placeholder="Username" required>
            <input type="password" id="password" name="password" placeholder="Password" required>
            <span class="toggle-password" id="toggle-password" onclick="togglePassword()">Lihat Password</span>
            <button type="submit">Login</button>
            <button type="button" class="clear" onclick="clearForm()">Clear</button>
            <button type="button" class="register" onclick="location.href='register.php'">Registrasi</button>
        </form>

        <?php
        // Tampilkan pesan error jika login gagal
        if (isset($error_message)) {
            echo '<p class="error">' . $error_message . '</p>';
        }
        ?>
    </div>
    <footer>
        &copy; <?php echo date("Y"); ?> Restoran Mz. Semua Hak Dilindungi.
    </footer>
</body>
</html>
