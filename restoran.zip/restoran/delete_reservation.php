<?php
include('db.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Get id_rsv from URL
$id_rsv = isset($_GET['id']) ? $_GET['id'] : '';

// Start a transaction to ensure data integrity
$conn->begin_transaction();

try {
    // Delete from rsvseat table (reservation-seat relationship)
    $sql_delete_rsvseat = "DELETE FROM rsvseat WHERE id_rsv = ?";
    $stmt = $conn->prepare($sql_delete_rsvseat);
    $stmt->bind_param("i", $id_rsv);
    $stmt->execute();

    // Delete from orders table
    $sql_delete_orders = "DELETE FROM orders WHERE id_rsv = ?";
    $stmt = $conn->prepare($sql_delete_orders);
    $stmt->bind_param("i", $id_rsv);
    $stmt->execute();

    // Delete from rsv table (main reservation table)
    $sql_delete_rsv = "DELETE FROM reservation WHERE id_rsv = ?";
    $stmt = $conn->prepare($sql_delete_rsv);
    $stmt->bind_param("i", $id_rsv);
    $stmt->execute();

    // Commit transaction
    $conn->commit();

    // Redirect to the reservations page with a success message
    header("Location: reservasi.php?success=1");
    exit();
} catch (Exception $e) {
    // Roll back if there's an error
    $conn->rollback();
    echo "Gagal menghapus data reservasi: " . $e->getMessage();
}
?>
