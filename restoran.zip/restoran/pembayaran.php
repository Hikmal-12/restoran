<?php
session_start();
include('db.php');

// Set timezone ke Cilegon
date_default_timezone_set('Asia/Jakarta');

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$current_user = $_SESSION['username'];
$current_time = date("Y-m-d H:i:s");

// Periksa apakah `order_id` tersedia
if (!isset($_GET['id_orders'])) {
    echo "No order selected.";
    exit();
}

$order_id = $_GET['id_orders'];

// Ambil detail pesanan dari database
$orderQuery = "SELECT orders.id_orders, orders.item_order, orders.total_order, customer.nm_cust 
               FROM orders 
               JOIN reservation ON orders.id_rsv = reservation.id_rsv
               JOIN customer  ON reservation.id_cust = customer.id_cust
               WHERE orders.id_orders = ?";
$stmtOrder = $conn->prepare($orderQuery);
$stmtOrder->bind_param("s", $order_id);
$stmtOrder->execute();
$orderResult = $stmtOrder->get_result();

if ($orderResult->num_rows === 0) {
    echo "Order not found.";
    exit();
}

$order = $orderResult->fetch_assoc();

// Ambil daftar menu dalam pesanan
$menuQuery = "SELECT menu.nm_menu, ordersmenu.qty_order, menu.price_menu, (ordersmenu.qty_order * menu.price_menu) AS total_price 
              FROM ordersmenu 
              JOIN menu  ON ordersmenu.id_menu = menu.id_menu
              WHERE ordersmenu.id_orders = ?";
$stmtMenu = $conn->prepare($menuQuery);
$stmtMenu->bind_param("s", $order_id);
$stmtMenu->execute();
$menuResult = $stmtMenu->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Pembayaran</title>
    <style>
        /* Tambahkan styling Anda di sini */
    </style>
</head>
<body>
    <h1>Pembayaran</h1>
    <p>Nama Customer: <?php echo $order['nm_cust']; ?></p>
    <p>No Order: <?php echo $order['id_orders']; ?></p>
    <p>Jumlah Item: <?php echo $order['item_orders']; ?></p>
    <p>Total Harga: Rp. <?php echo number_format($order['total_orders'], 0, ',', '.'); ?></p>

    <h3>Detail Pesanan</h3>
    <table border="1">
        <tr>
            <th>Nama Menu</th>
            <th>Jumlah</th>
            <th>Harga</th>
            <th>Total</th>
        </tr>
        <?php while ($menu = $menuResult->fetch_assoc()) : ?>
            <tr>
                <td><?php echo $menu['nm_menu']; ?></td>
                <td><?php echo $menu['qty_order']; ?></td>
                <td>Rp. <?php echo number_format($menu['price_menu'], 0, ',', '.'); ?></td>
                <td>Rp. <?php echo number_format($menu['total_price'], 0, ',', '.'); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <form method="POST" action="selesai.php">
        <input type="hidden" name="id_orders" value="<?php echo $order_id; ?>">
        <button type="submit" name="bayar">Bayar</button>
    </form>
</body>
</html>
