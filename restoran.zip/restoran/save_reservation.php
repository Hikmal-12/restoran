<?php
include('db.php');
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Set timezone to Cilegon, Indonesia
date_default_timezone_set('Asia/Jakarta');

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $datetime_rsv = $_POST['datetime_rsv'];
    $reservasi_untuk = $_POST['reservasi_untuk'];
    $nm_cust = $_POST['nm_cust'];
    $phn_cust = $_POST['phn_cust'];
    $addr_cust = $_POST['addr_cust'];
    $nperson_rsv = $_POST['nperson_rsv'];
    $id_seat = $_POST['id_seat'];
    $desc_rsv = $_POST['desc_rsv'];

    // Insert customer information (if not already existing)
    $sql_insert_cust = "INSERT INTO customer (desc_cust, nm_cust, phn_cust, addr_cust) VALUES (?, ?, ?, ?)";
    $stmt_cust = $conn->prepare($sql_insert_cust);
    if ($stmt_cust) {
        $desc_cust = ''; // Customize if there's specific info
        $stmt_cust->bind_param("ssss", $desc_cust, $nm_cust, $phn_cust, $addr_cust);
        $stmt_cust->execute();
        $id_cust = $stmt_cust->insert_id;
        $stmt_cust->close();
    } else {
        die("Error preparing customer statement: " . $conn->error);
    }

    // Insert reservation data into 'rsv' table
    $sql_insert_rsv = "INSERT INTO reservation (id_cust, datetime_rsv, ordertime_rsv, nperson_rsv, desc_rsv, status_rsv) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt_rsv = $conn->prepare($sql_insert_rsv);
    if ($stmt_rsv) {
        $status_rsv = 'Pending'; // Set default status
        $stmt_rsv->bind_param("ississ", $id_cust, $datetime_rsv, $reservasi_untuk, $nperson_rsv, $desc_rsv, $status_rsv);
        $stmt_rsv->execute();
        $id_rsv = $stmt_rsv->insert_id;
        $stmt_rsv->close();
    } else {
        die("Error preparing reservation statement: " . $conn->error);
    }

    // Insert reservation-seat data into 'rsvseat' table
    $sql_insert_rsvseat = "INSERT INTO rsvseat (id_rsv, id_seat) VALUES (?, ?)";
    $stmt_rsvseat = $conn->prepare($sql_insert_rsvseat);
    if ($stmt_rsvseat) {
        $stmt_rsvseat->bind_param("ii", $id_rsv, $id_seat);
        $stmt_rsvseat->execute();
        $stmt_rsvseat->close();
    } else {
        die("Error preparing rsvseat statement: " . $conn->error);
    }

    // Redirect to the reservation page with a success message
    header("Location: reservasi.php?success=1");
    exit();
}
?>
