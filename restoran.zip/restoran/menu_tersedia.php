<?php
session_start();
include 'db.php'; // Koneksi ke database

// Mendapatkan nama pengguna yang sedang login dan waktu saat ini di Cilegon, Indonesia
date_default_timezone_set('Asia/Jakarta');
$current_user = $_SESSION['username'];
$current_time = date("Y-m-d H:i:s");

// Mengambil data semua menu dari tabel 'menu'
$sql = "SELECT * FROM menu";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Tersedia</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <style>
        /* Styling dasar */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #FAF9F6;
            margin: 0;
            padding: 0;
            color: #333;
        }
        .sidebar {
            width: 250px;
            background-color: #FFDAB9;
            padding: 20px;
            height: 100vh;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed;
        }
        .sidebar h2 {
            font-family: 'Forte', cursive;
            font-size: 28px;
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar p {
            text-align: center;
            font-weight: bold;
            color: #555;
        }
        .sidebar nav button {
            width: 100%;
            background-color: #FF7F50;
            color: #fff;
            border: none;
            padding: 10px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .sidebar nav button:hover {
            background-color: #FF6347;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }
        .content {
            margin-left: 270px;
            padding: 20px;
            background-color: #fff;
        }
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .content h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
            border-bottom: 2px solid #FFA07A;
            padding-bottom: 5px;
        }
        .category-buttons {
            display: flex;
            gap: 10px;
        }
        .category-buttons button {
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #FFA07A;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .category-buttons button:hover {
            background-color: #FF4500;
        }
        .menu-item {
            display: grid;
            grid-template-columns: 1fr 2fr 1fr 3fr 1fr;
            gap: 15px;
            padding: 20px;
            background-color: #FFF0F5;
            margin-bottom: 15px;
            border-radius: 8px;
            align-items: center;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .menu-item:hover {
            transform: scale(1.02);
        }
        .menu-item img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
        }
        .action-buttons {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }
        .action-buttons button {
            padding: 10px;
            font-size: 16px;
            color: #fff;
            background-color: #FFA07A;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .action-buttons button:hover {
            background-color: #FF4500;
        }
        .reservasi-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #FFA07A;
            color: #fff;
            padding: 15px;
            font-size: 18px;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .reservasi-button:hover {
            background-color: #FF4500;
            transform: scale(1.1);
        }

        /* Styling responsif */
        @media screen and (max-width: 768px) {
            .sidebar { width: 100%; height: auto; position: relative; }
            .content { margin-left: 0; }
            .menu-item {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .content-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .reservasi-button { bottom: 10px; right: 10px; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>Resto Mz</h2>
    <p>Selamat datang, <?php echo $current_user; ?>!</p>
    <p><?php echo $current_time; ?></p>
    <nav>
        <button onclick="location.href='dashboard.php'">Dashboard</button>
        <button onclick="location.href='seat.php'">Seat</button>
        <button onclick="location.href='menu_tersedia.php'">Menu</button>
        <button onclick="location.href='reservasi.php'">Reservasi</button>
        <button onclick="location.href='pesanan.php'">Pesanan</button>
        <button onclick="location.href='pembayaran.php'">Bayar</button>
        <button onclick="location.href='logout.php'">Logout</button>
    </nav>
</div>

<div class="content">
    <div class="content-header">
        <h1>Menu Tersedia</h1>
        <div class="category-buttons">
            <button onclick="filterCategory('Makanan')">Makanan</button>
            <button onclick="filterCategory('Minuman')">Minuman</button>
            <button onclick="filterCategory('Cemilan')">Snack</button>
            <button onclick="filterKosong('Kosong')">Menu Kosong</button>
        </div>
    </div>
    <p>Detail semua menu berdasarkan Menu Detail Rekomendasi:</p>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $category_class = strtolower($row['cat_menu']);
            echo "<div class='menu-item {$category_class} " . ($row['status_menu'] == 'Kosong' ? 'Kosong' : '') . "'>";
            echo "<img src='images/{$row['pic_menu']}' alt='Foto Menu'>";
            echo "<div><strong>{$row['nm_menu']}</strong></div>";
            echo "<div>Rp " . number_format($row['price_menu'], 0, ',', '.') . "</div>";
            echo "<div>{$row['desc_menu']}</div>";
            echo "</div>";
        }
    } else {
        echo "<p>Tidak ada item menu yang tersedia.</p>";
    }
    ?>

    <div class="action-buttons">
        <button onclick="location.href='tambah_menu.php'">Tambah Menu</button>
    </div>
</div>

<button class="reservasi-button" onclick="location.href='pesanan.php'">Reservasi</button>


<script>
    function filterCategory(category) {
        document.querySelectorAll('.menu-item').forEach(item => {
            item.style.display = 'none';
        });

        document.querySelectorAll('.' + category.toLowerCase()).forEach(item => {
            item.style.display = 'grid';
        });
    }

    function filterKosong() {
        document.querySelectorAll('.menu-item').forEach(item => {
            item.style.display = 'none';
        });

        document.querySelectorAll('.Kosong').forEach(item => {
            item.style.display = 'grid';
        });
    }

    document.addEventListener("DOMContentLoaded", function() {
        document.querySelectorAll('.menu-item').forEach(item => {
            item.style.display = 'grid';
        });
    });
</script>

</body>
</html>
