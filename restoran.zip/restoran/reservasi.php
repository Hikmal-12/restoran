<?php
include('db.php');
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Set timezone to Cilegon, Indonesia
date_default_timezone_set('Asia/Jakarta');

// Get current date and time in the desired format
$now = date("d-m-Y H:i");

// Get logged-in user's name from the session
$username = $_SESSION['username'];

if (isset($_GET['success']) && $_GET['success'] == 1): ?>
    <p style="color: green;">Reservasi berhasil disimpan!</p>
<?php endif; ?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Daftar Reservasi</title>
    <style>
        /* Styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }
        .sidebar {
            float: left;
            width: 20%;
            background-color: #4b6584;
            padding: 15px;
            height: 100vh;
            color: white;
        }
        .sidebar h3 {
            font-family: Forte, Arial, sans-serif;
            font-size: 26px;
            text-align: center;
            color: #ffd700;
        }
        .sidebar button {
            display: block;
            width: 100%;
            margin-bottom: 15px;
            padding: 12px;
            background-color: #ffd700;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color: #4b6584;
            transition: background-color 0.3s, color 0.3s;
        }
        .sidebar button:hover {
            background-color: #4b6584;
            color: #ffd700;
        }
        .container {
            margin-left: 22%;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container h2 {
            color: #4b6584;
            font-family: 'Forte', sans-serif;
        }
        .form-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }
        .form-group label {
            font-weight: bold;
            color: #4b6584;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .btn {
            padding: 10px 15px;
            background-color: #4b6584;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
            border-radius: 5px;
        }
        .btn-secondary {
            background-color: #ffd700;
            color: #4b6584;
            font-weight: bold;
            margin-left: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #ffffff;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #4b6584;
            color: white;
            font-weight: bold;
        }
        td {
            border-bottom: 1px solid #ddd;
        }
        .action-links a {
            margin-right: 10px;
            color: #4b6584;
            text-decoration: none;
            font-weight: bold;
        }
        .action-links a:hover {
            color: #ffd700;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h3>Resto Mz</h3>
    <button onclick="location.href='dashboard.php'">Dashboard</button>
    <button onclick="location.href='seat.php'">Seat</button>
    <button onclick="location.href='menu_tersedia.php'">Menu</button>
    <button onclick="location.href='reservasi.php'">Reservasi</button>
    <button onclick="location.href='pesanan.php'">Pesanan</button>
    <button onclick="location.href='pembayaran.php'">Bayar</button>
    <button onclick="location.href='logout.php'">Logout</button>
</div>

<div class="container">
    <h2>Reservasi</h2>
    <p>Selamat datang, <?php echo htmlspecialchars($username); ?> | <?php echo $now; ?></p>

    <!-- Reservation Form -->
    <div class="form-container">
        <form method="POST" action="save_reservation.php">
            <div class="form-group">
                <label>Tanggal Reservasi:</label>
                <input type="datetime-local" name="datetime_rsv" value="<?php echo date('Y-m-d\TH:i'); ?>" required>
            </div>
            <div class="form-group">
                <label>Reservasi untuk:</label>
                <input type="datetime-local" name="reservasi_untuk" required>
            </div>
            <div class="form-group">
                <label>Nama Customer:</label>
                <input type="text" name="nm_cust" required>
            </div>
            <div class="form-group">
                <label>Telepon Customer:</label>
                <input type="text" name="phn_cust" required>
            </div>
            <div class="form-group">
                <label>Alamat Customer:</label>
                <input type="text" name="addr_cust" required>
            </div>
            <div class="form-group">
                <label>Jumlah Tamu:</label>
                <input type="number" name="nperson_rsv" required>
            </div>
            <div class="form-group">
                <label>Seat:</label>
                <select name="id_seat" required>
                    <?php
                    $seatQuery = "SELECT id_seat, nm_seat, cap_seat, desc_seat FROM seat";
                    $seatResult = $conn->query($seatQuery);
                    while ($seat = $seatResult->fetch_assoc()) {
                        echo "<option value='{$seat['id_seat']}'>{$seat['nm_seat']} | Capacity: {$seat['cap_seat']} | {$seat['desc_seat']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Pesan-pesan:</label>
                <textarea name="desc_rsv"></textarea>
            </div>
            <button type="submit" class="btn">Simpan RSV</button>
            <button type="button" class="btn btn-secondary" onclick="location.href='menu_tersedia.php'">Lanjut Pesan</button>
        </form>
    </div>

    <!-- Reservation List Table -->
    <table>
        <tr>
            <th>No</th>
            <th>Tanggal RSV</th>
            <th>Reservasi untuk</th>
            <th>Nama Cust</th>
            <th>Telepon Cust</th>
            <th>Alamat Cust</th>
            <th>Jumlah Tamu</th>
            <th>Seat</th>
            <th>Pesan-pesan</th>
            <th>Aksi</th>
        </tr>

        <?php
        $sql = "SELECT reservation.id_rsv, reservation.datetime_rsv, reservation.ordertime_rsv, customer.nm_cust, customer.phn_cust, customer.addr_cust, seat.nm_seat, reservation.nperson_rsv, reservation.desc_rsv
                FROM reservation
                JOIN customer ON reservation.id_cust = customer.id_cust
                JOIN rsvseat ON reservation.id_rsv = rsvseat.id_rsv
                JOIN seat ON rsvseat.id_seat = seat.id_seat";
                
        $result = $conn->query($sql);
        $no = 1;
        
        // Display reservation data in table format
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$no}</td>
                    <td>" . date("d-m-Y H:i", strtotime($row['datetime_rsv'])) . "</td>
                    <td>" . date("d-m-Y H:i", strtotime($row['ordertime_rsv'])) . "</td>
                    <td>{$row['nm_cust']}</td>
                    <td>{$row['phn_cust']}</td>
                    <td>{$row['addr_cust']}</td>
                    <td>{$row['nperson_rsv']}</td>
                    <td>{$row['nm_seat']}</td>
                    <td>{$row['desc_rsv']}</td>
                    <td class='action-links'>
                        <a href='edit_reservation.php?id={$row['id_rsv']}'>Edit</a>
                        <a href='delete_reservation.php?id={$row['id_rsv']}'>Hapus</a>
                    </td>
                  </tr>";
            $no++;
        }
        ?>
    </table>
</div>

</body>
</html>
