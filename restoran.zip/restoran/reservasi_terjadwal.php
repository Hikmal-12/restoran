<?php
include('db.php');
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Mengambil nama user yang login
$username = $_SESSION['username'];
$user_query = $conn->query("SELECT nm_user FROM user WHERE username = '$username'");
$user_data = $user_query->fetch_assoc();
$nm_user = $user_data['nm_user'];

// Set timezone dan ambil waktu sekarang di Jakarta
date_default_timezone_set("Asia/Jakarta");
$tgl_jam_sekarang = date("d-m-Y H:i");

// Query untuk menampilkan booking hari ini
$tanggal_hari_ini = date("Y-m-d");
$today_reservations = $conn->query("SELECT c.nm_cust, c.phn_cust, c.addr_cust, r.nperson_rsv, s.nm_seat, s.cap_seat, r.desc_rsv
                                    FROM reservation AS r
                                    JOIN customer AS c ON r.id_cust = c.id_cust
                                    JOIN rsvseat AS rs ON r.id_rsv = rs.id_rsv
                                    JOIN seat AS s ON rs.id_seat = s.id_seat
                                    WHERE DATE(r.datetime_rsv) = '$tanggal_hari_ini'");

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Booking Reservation Terjadwal</title>
    <style>
        /* Global Styles */
        body { font-family: 'Arial', sans-serif; background-color: #f3f4f6; margin: 0; padding: 0; color: #333; }
        .container { display: flex; min-height: 100vh; }

        /* Sidebar Styles */
        .sidebar {
            width: 220px;
            background-color: #333;
            color: white;
            padding: 20px;
        }
        .sidebar button {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f4b41a;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
            color: #333;
        }
        .sidebar button:hover {
            background-color: #d49e00;
        }

        /* Main Content Styles */
        .content {
            flex: 1;
            padding: 20px;
            background-color: #f9fafb;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            color: #4CAF50;
        }
        .header h2 {
            font-size: 24px;
        }

        /* Booking Details Section */
        h3 { color: #4CAF50; }
        .kotak-kotak {
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            max-height: 300px;
            border: 1px solid #ddd;
            padding: 10px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .kotak {
            display: grid;
            grid-template-columns: repeat(8, 1fr);
            padding: 10px;
            border: 1px solid #ddd;
            margin-bottom: 10px;
            background-color: #e7f5e4;
            border-radius: 4px;
            font-size: 14px;
        }
        .kotak span {
            padding: 5px;
            font-weight: bold;
        }
        .kotak button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            padding: 5px;
            border-radius: 5px;
            font-size: 12px;
        }

        /* Form and Button Styles */
        form {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
            margin-bottom: 20px;
        }
        input[type="date"], button {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
        }
        .add-reservation {
            background-color: #28a745;
            color: white;
            padding: 10px;
            text-align: center;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 20px;
            transition: background 0.3s;
        }
        .add-reservation:hover {
            background-color: #218838;
        }

        /* Responsive Layout */
        @media (max-width: 768px) {
            .container { flex-direction: column; }
            .sidebar { width: 100%; }
            .content { padding: 10px; }
            .kotak { grid-template-columns: repeat(2, 1fr); }
            .header h2 { font-size: 20px; }
        }

        @media (max-width: 480px) {
            .kotak { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar with navigation buttons -->
        <div class="sidebar">
            <button onclick="location.href='dashboard.php'">Dashboard</button>
            <button onclick="location.href='seat.php'">Seat</button>
            <button onclick="location.href='menu_tersedia.php'">Menu</button>
            <button onclick="location.href='reservasi.php'">Reservasi</button>
            <button onclick="location.href='pesanan.php'">Pesanan</button>
            <button onclick="location.href='pembayaran.php'">Bayar</button>
            <button onclick="location.href='logout.php'">Logout</button>
        </div>

        <!-- Main content -->
        <div class="content">
            <!-- Header with user information -->
            <div class="header">
                <h2>Booking Reservasi</h2>
                <div>Selamat datang, <?php echo $nm_user; ?> | <?php echo $tgl_jam_sekarang; ?></div>
            </div>

            <!-- Detail Booking Seat Hari Ini Section -->
            <h3>Detail Booking Seat Hari Ini</h3>
            <div class="kotak-kotak">
                <div class="kotak" style="font-weight: bold;">
                    <span>Nama Cust</span><span>Telepon</span><span>Alamat</span><span>Orang</span>
                    <span>Nama Seat</span><span>Kapasitas</span><span>Deskripsi</span><span>Status</span>
                </div>
                <?php
                while ($row = $today_reservations->fetch_assoc()) {
                    echo "<div class='kotak'>
                            <span>{$row['nm_cust']}</span>
                            <span>{$row['phn_cust']}</span>
                            <span>{$row['addr_cust']}</span>
                            <span>{$row['nperson_rsv']}</span>
                            <span>{$row['nm_seat']}</span>
                            <span>{$row['cap_seat']}</span>
                            <span>{$row['desc_rsv']}</span>
                            <span>Pesan Menu</span>
                          </div>";
                }
                ?>
            </div>

            <!-- Date Range Filter -->
            <h3>Lihat Booking Tanggal</h3>
            <form method="GET" action="">
                <label>Dari Tanggal:</label>
                <input type="date" name="from_date" required placeholder="Dari Tanggal">
                <label>Sampai Tanggal:</label>
                <input type="date" name="to_date" required placeholder="Sampai Tanggal">
                <button type="submit">Lihat</button>
            </form>

            <div class="kotak-kotak">
                <div class="kotak" style="font-weight: bold;">
                    <span>Nama Cust</span><span>Telepon</span><span>Alamat</span><span>Orang</span>
                    <span>Nama Seat</span><span>Kapasitas</span><span>Deskripsi</span><span>Status</span>
                </div>
                <?php
                if (isset($_GET['from_date']) && isset($_GET['to_date'])) {
                    $from_date = $_GET['from_date'];
                    $to_date = $_GET['to_date'];

                    // Query berdasarkan rentang tanggal
                    $filtered_reservations = $conn->query("SELECT c.nm_cust, c.phn_cust, c.addr_cust, r.nperson_rsv, s.nm_seat, s.cap_seat, r.desc_rsv
                                                           FROM reservation AS r
                                                           JOIN customer AS c ON r.id_cust = c.id_cust
                                                           JOIN rsvseat AS rs ON r.id_rsv = rs.id_rsv
                                                           JOIN seat AS s ON rs.id_seat = s.id_seat
                                                           WHERE DATE(r.datetime_rsv) BETWEEN '$from_date' AND '$to_date'");

                    // Tampilkan hasil filter
                    while ($row = $filtered_reservations->fetch_assoc()) {
                        echo "<div class='kotak'>
                                <span>{$row['nm_cust']}</span>
                                <span>{$row['phn_cust']}</span>
                                <span>{$row['addr_cust']}</span>
                                <span>{$row['nperson_rsv']}</span>
                                <span>{$row['nm_seat']}</span>
                                <span>{$row['cap_seat']}</span>
                                <span>{$row['desc_rsv']}</span>
                                <span>Pesan Menu</span>
                              </div>";
                    }
                }
                ?>
            </div>

            <!-- Button to add a new reservation -->
            <div class="add-reservation" onclick="location.href='reservasi.php'">
                Tambah Reservasi
            </div>
        </div>
    </div>
</body>
</html>
