<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Selamat datang di Admin Dashboard</h1>
    <p>Halo, <?php echo $_SESSION['username']; ?></p>
    <!-- Tambahkan kode untuk menampilkan data dan opsi manajemen untuk admin -->
</body>
</html>
